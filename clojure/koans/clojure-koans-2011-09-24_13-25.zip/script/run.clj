(load "path_to_enlightenment")
(do
  (in-ns 'path-to-enlightenment)
  (run))