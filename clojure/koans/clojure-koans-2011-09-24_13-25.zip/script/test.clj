(load "path_to_answer_sheet")
(do
  (in-ns 'path-to-answer-sheet)
  (run))