(meditations
  "We shall contemplate truth by testing reality, via equality."
  (= __ true)

  "To understand reality, we must compare our expectations against reality."
  (= __ (+ 1 1))

  "You can test equality of many things"
  (= (+ 3 4) __ (+ 2 __))

  "Some things may appear different, but be the same"
  (= 2 2/1 __)

  "You cannot generally float to heavens of integers"
  (= __ (= 2 2.0))

  "But a looser equality is also possible"
  (== 2.0 2 __)

  "When things cannot be equal, they must be different"
  (not= :fill-in-the-blank __))
